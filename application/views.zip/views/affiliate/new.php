
<div class="col-lg-9">
				
				

<h1>new page</h1>
<?php echo $name;?>
</div>