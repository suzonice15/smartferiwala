
<div class="container container-fullwidth" style="margin-bottom: 50px">
	<div class="container-fluid">

<div class="row">
	<div class="col-md-12">
		<div class="subheader">
			<ul class="breadcrumb">
				<li><a href="<?=base_url()?>">Home</a>/</li>
				<li class="active" style="margin-left: 5px;"><?=$page_title?></li>
			</ul>

			<div class="page-title ">

			</div>
			<br>
		</div>
		</div>


	<div class="col-md-12">

		<article class="txt">
			<?=$page_content?>
		</article>
	</div>


	</div>

	</div>
	</div>
