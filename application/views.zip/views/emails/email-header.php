<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo get_option('site_title'); ?></title>
	<style type="text/css">
	body{margin:0;padding:0;}
	.wrapper{background:#f1f1f1;padding:40px 0;}
	.template-header{background:#074488;width:600px;border-radius:4px 4px 0 0;}
	.template-header img{display:block;margin:auto;height:40px;padding:10px;}
	a{color:#074488;text-decoration:none;}
	</style>
</head>
<body>
<div class="wrapper">
	<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
    	<tr>
        	<td align="center" valign="top">
				<div class="template-header">
					<img src="<?=base_url('applications/views/emails/images/email-logo.png')?>" alt="<?php echo get_option('site_title'); ?>">
				</div>