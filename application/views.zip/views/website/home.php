<?php $this->load->view('website/header');?>

<?php echo $home;?>

<?php $this->load->view('website/footer');?>
